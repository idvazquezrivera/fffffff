---
name: "\U0001F914Support question"
about: Ask the community
title: ''
labels: question
assignees: ''

---

**You've got questions?**

We primarily use GitHub as an issue tracker; for usage and support questions, please check out these resources below. Thanks! 😁

* README.md: https://github.com/silkimen/cordova-plugin-advanced-http/blob/master/README.md
* StackOverflow: https://stackoverflow.com/questions/tagged/cordova-plugin-advanced-http using the tag `cordova-plugin-advanced-http`
* Wiki: https://github.com/silkimen/cordova-plugin-advanced-http/wiki

And don't forget: If you get help, help others. Good karma rulez!
